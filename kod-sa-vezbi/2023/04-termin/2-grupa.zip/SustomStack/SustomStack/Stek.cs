﻿using System;

namespace SustomStack
{
    delegate bool Filter<T>(T val);

    class Stek<T>
    {
        T[] elementi;
        int vrh = -1;

        public Stek(int kapacitet)
        {
            elementi = new T[kapacitet];
        }

        public void Dodaj(T novi)
        {
            if (vrh < elementi.Length - 1)
                elementi[++vrh] = novi;
        }

        public Stek<T> Filtriraj(Filter<T> filter)
        {
            var novi = new Stek<T>(elementi.Length);
            foreach (T e in elementi)
            {
                if (filter(e))
                    novi.Dodaj(e);
            }
            return novi;
        }

        public void FilterInPlace(Filter<T> filter)
        {
            T[] stariNiz = elementi;
            elementi = new T[elementi.Length];
            vrh = -1;

            foreach (T e in stariNiz)
            {
                if (filter(e))
                    this.Dodaj(e);
            }
        }

        public void Print()
        {
            Console.Write("Stek (" + elementi.Length + ")");
            for (int i = 0; i <= vrh; i++)
            {
                Console.Write(" | " + elementi[i]);
            }
            Console.WriteLine();
        }
    }
}
