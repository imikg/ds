﻿using System;

namespace SustomStack
{
    class Program
    {
        static void Main(string[] args)
        {
            Stek<int> brojevi = new Stek<int>(10);
            brojevi.Dodaj(1);
            brojevi.Dodaj(-2);
            brojevi.Dodaj(3);
            brojevi.Dodaj(-4);
            brojevi.Dodaj(5);

            Filter<int> poz = (x) => x > 0;
            Filter<int> v2 = (x) => x > 2;

            var noviBrojevi = brojevi.Filtriraj(poz);

            brojevi.Print();
            noviBrojevi.Print();

            brojevi.FilterInPlace(v2);

            brojevi.Print();
        }
    }
}
