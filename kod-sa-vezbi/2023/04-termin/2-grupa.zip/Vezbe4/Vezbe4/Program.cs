﻿using System;

namespace Vezbe4
{
    delegate Point<T> Filter<T>(Point<T> p);

    class Program
    {
        static Point<Tip> NewPoint<Tip>()
        {
            // return new Point<Tip>();
        }

        static K Novi<K>()
        {
            return new K();
        }

        static void Main(string[] args)
        {
            Point<int> point1 = new Point<int>(3, 5);
            Point<int> p1 = new Point<int>(1, 2);
            Point<float> point2 = new Point<float>(1.2f, 3.4f);
            Point<long> point3 = new Point<long>(1, 2);

            Novi<Point<int>>();

            var point4 = NewPoint<short>(); // Point<short>

            Filter<float> f = (p) => p;
            // Point<float> point5 = f(point1);

            // ----------------------------

            

            var p6 = new Point<Point<int>>(point1, p1);
        }
    }

    class Point<T>
    {
        T x;
        T y;

        //public Point() { }

        public Point(T x, T y)
        {
            this.x = x;
            this.y = y;
        }
    }


}
