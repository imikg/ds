﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolokvijum
{
    class Node<T>
    {
        public T vrednost;
        public Node<T> sledeci;

        public Node(T vrednost)
        {
            this.vrednost = vrednost;
            this.sledeci = null;
        }
    }
}
