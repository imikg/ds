﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolokvijum
{
    class Program
    {
        public static void StampajStaticno()
        {
            Console.WriteLine("Buffer je prazan (staticno) ");
        }

        public static string linija = "\n------------------------------------------------------------------\n";

        static void Main(string[] args)
        {
            Broj b1 = new Broj(1);
            Broj b2 = new Broj(2);
            Broj b3 = new Broj(3);

            BufferedList<Broj> buffer = new BufferedList<Broj>();
            buffer.Dodaj(b1);
            buffer.Dodaj(b2);
            buffer.Dodaj(b3);

            Console.WriteLine(linija);
            Console.WriteLine("Ispis buffera preko foreach : ");
            foreach (Broj broj in buffer) Console.Write(broj);
            Console.WriteLine("\n" + linija);

            buffer.PrazanBafer += () => { Console.WriteLine("Buffer je prazan (anoninmno)"); };
            buffer.PrazanBafer += StampajStaticno;

            Broj izbacen = buffer.Izbaci();

            // Ovo odkomentarisati da bi se jednom pozvao PrazanBafer event (ali za obe fje - tako da ce biti 2 ispisa);
            
            /*
            Broj izbacen1 = buffer.Izbaci();
            Broj izbacen2 = buffer.Izbaci();
            Broj izbacen3 = buffer.Izbaci(); 
            */

            Console.WriteLine("Ispis buffera nakon izbacivanja : ");
            foreach (Broj broj in buffer) Console.Write(broj);
            Console.WriteLine("\n");
            Console.WriteLine("Izbacen je broj : " + izbacen);
            Console.WriteLine(linija);

            Console.WriteLine("[1] vrednost u bufferu je : " + buffer[1] + " ( koriscenjem indeksera )."); // Ukoliko mu se zada nepostojeci indeks, vratice null, tj nece ispisati nijedan broj
            Console.WriteLine(linija);

            Console.WriteLine("[5] vrednost u bufferu (ne postoji) je : " + buffer[5] + " ( koriscenjem indeksera )."); // Ukoliko mu se zada nepostojeci indeks, vratice null, tj nece ispisati nijedan broj
            Console.WriteLine(linija);

            BufferedList<Broj> buffer2 = new BufferedList<Broj>();
            buffer2.Dodaj(b1);

            Console.WriteLine("Buffer 1 : ");
            foreach (Broj broj in buffer) Console.Write(broj);
            Console.WriteLine("\n" + linija);

            Console.WriteLine("Buffer 2 : ");
            foreach (Broj broj in buffer2) Console.Write(broj);
            Console.WriteLine("\n" + linija);

            BufferedList<Broj> zbirBuffera = buffer + buffer2;
            Console.WriteLine("Zbir buffera : ");
            foreach (Broj broj in zbirBuffera) Console.Write(broj);
            Console.WriteLine("\n" + linija);

            BufferedList<Broj> zbirBufferaIElementa = zbirBuffera + b3;
            Console.WriteLine("Zbir buffera i elementa broja 3: ");
            foreach (Broj broj in zbirBufferaIElementa) Console.Write(broj);
            Console.WriteLine("\nDuzina ovog buffera je " + zbirBufferaIElementa.Length + " (koriscenjem propery Length i get-a)");
            Console.WriteLine(linija);
    

            int brojOduzimanja = 2; // Za pozivanje eventa , staviti 6 npr, treba da podigne event 2 puta jer je duzina buffera 4, za ne pozivanje eventa moze 2 
            Console.WriteLine("Izbacujem element " + brojOduzimanja + " puta..\n");
            BufferedList<Broj> bufferNakonOduzimanja = zbirBufferaIElementa - brojOduzimanja;
 
            Console.WriteLine("\nBuffer zbiraBufferaIElementa nakon oduzimanja " + brojOduzimanja + " puta : ");
            foreach (Broj broj in bufferNakonOduzimanja) Console.Write(broj);
            Console.WriteLine("\n" + linija);


            Console.WriteLine("Buffer 1 i Buffer 2 su jednaki ? : " + (buffer==buffer2).ToString()); // false;
            Console.WriteLine("Buffer 1 i Buffer 2 su razliciti ? : " + (buffer != buffer2).ToString()); // true

            Console.WriteLine("Buffer 1 i Buffer 1 su jednaki ? : " + (buffer == buffer).ToString()); // true
            Console.WriteLine("Buffer 1 i Buffer 1 su razliciti ? : " + (buffer != buffer).ToString()); // false
            Console.WriteLine(linija);

            Broj[] nizBrojeva = (Broj[])(buffer);
            Console.WriteLine("Buffer 1 prebacen u niz : ");
            foreach (Broj broj in nizBrojeva) Console.Write(broj);
            Console.WriteLine("\n" + linija);

        }
    }
}
