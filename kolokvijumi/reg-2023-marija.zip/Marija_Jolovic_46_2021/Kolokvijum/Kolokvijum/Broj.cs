﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolokvijum
{
    class Broj : IJednakost<Broj>
    {
        int br;
        public Broj(int br)
        {
            this.br = br;
        }
        public override string ToString()
        {
            return br.ToString() + " ";
        }


        public bool DaLiSuJednaki(Broj prom)
        {
            return this.br == prom.br;
        }
    }
}
