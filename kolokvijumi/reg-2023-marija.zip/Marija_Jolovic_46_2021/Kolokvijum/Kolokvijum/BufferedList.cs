﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kolokvijum
{
    class BufferedList<T> : IEnumerable<T> where T : class, IJednakost<T>
    {
        Node<T> pocetak;

        public delegate void PrazanBaferHandler();
        public event PrazanBaferHandler PrazanBafer;

        public int Length
        {
            get
            {
                Node<T> pom = this.pocetak;
                int br = 0;
                while (pom != null)
                {
                    pom = pom.sledeci;
                    br++;
                }
                return br;
            }
        }

        public void Dodaj(T element)
        {
            if (this.pocetak == null)
            {
                pocetak = new Node<T>(element);
                return;
            }
            Node<T> pom = this.pocetak;
            while (pom.sledeci != null)
                pom = pom.sledeci;
            pom.sledeci = new Node<T>(element);  
        }

        public T Izbaci()
        {
            if (this.pocetak != null)
            {
                T izbacenaVrednost = pocetak.vrednost;

                pocetak = pocetak.sledeci;

                return izbacenaVrednost;
            }
            else
            {
                if (PrazanBafer!=null) PrazanBafer();
                return null;
            }
        }

        public T this[int indeks]
        {
            get
            {
                if (indeks >= Length) return null;
                Node<T> pom = this.pocetak;
                for (int i = 0; i < indeks; i++) pom = pom.sledeci;
                return pom.vrednost;
            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            for (int i = 0; i < Length; i++)
                yield return this[i];
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        public static BufferedList<T> operator +(BufferedList<T> t1, BufferedList<T> t2)
        {
            BufferedList<T> zbir = new BufferedList<T>();

            foreach (T el in t1) zbir.Dodaj(el);
            foreach (T el in t2) zbir.Dodaj(el);

            return zbir;
        }

        public static BufferedList<T> operator +(BufferedList<T> t1, T noviElement)
        {
            BufferedList<T> zbir = new BufferedList<T>();

            foreach (T el in t1) zbir.Dodaj(el);
            zbir.Dodaj(noviElement);

            return zbir;
        }

        public static BufferedList<T> operator -(BufferedList<T> t1, int brojSkidanja)
        {
            BufferedList<T> razlika = new BufferedList<T>();
            razlika.PrazanBafer += Program.StampajStaticno;
            razlika.PrazanBafer += () => { Console.WriteLine("Buffer je prazan (anoninmno)"); };

            foreach (T el in t1) razlika.Dodaj(el);

            for (int i = 0; i < brojSkidanja ; i++) razlika.Izbaci();

            return razlika;
        }

        public static bool operator ==(BufferedList<T> t1, BufferedList<T> t2)
        {

            if (t1.Length != t2.Length) return false;

            for (int i = 0; i < t1.Length; i++)
                if (t1[i].DaLiSuJednaki(t2[i]) == false) return false; // cim neki par nije jednak, vraca false;
            
            // ako je stigao dovde, znaci da su svi clanovi redom bbili jednaki
            return true;
        }
        public static bool operator !=(BufferedList<T> t1, BufferedList<T> t2)
        {
            return !(t1 == t2);
        }

        public static explicit operator T[](BufferedList<T> buffer)
        {
            T[] niz = new T[buffer.Length];
            
            for (int i = 0; i < buffer.Length; i++) niz[i] = buffer[i];

            return niz;
        }


    }
}
