﻿using System.Collections.Generic;

namespace HashMapApp
{
    delegate void HashDelegate(string hash);

    internal class HashMap<T> where T : class, IHash
    {
        public event HashDelegate NonExistingHash;

        public HashList<T> firstList;
        public int Length
        {
            get {
                var len = 0;
                foreach (var list in Iter())
                    foreach (var item in list.Iter())
                        len++;
                return len;
            }
        }

        public void Add(T val)
        {
            var hash = val.GetHash();
            var list = this[hash];

            if (list != null) 
            {
                list.Add(val);
            }
            else
            {
                var newList = new HashList<T>(hash);
                newList.Add(val);

                if (firstList == null)
                {
                    firstList = newList;
                    return;
                }

                var lastList = firstList;
                foreach (var item in Iter())
                    lastList = item;

                lastList.next = newList;
            }
        }

        public void Sort()
        {
            foreach (var list in Iter())
            {
                var otherList = list.next;
                while (otherList != null && otherList.hash.CompareTo(list.hash) >= 0)
                    otherList = otherList.next;

                if (otherList != null)
                {
                    var h = list.hash;
                    list.hash = otherList.hash;
                    otherList.hash = h;

                    var n = list.firstNode;
                    list.firstNode = otherList.firstNode;
                    otherList.firstNode = n;
                }
            }
        }

        public IEnumerable<HashList<T>> Iter()
        {
            var hl = firstList;
            while (hl != null)
            {
                yield return hl;
                hl = hl.next;
            }
        }

        public HashList<T> this[string hash]
        {
            get {
                foreach (var list in Iter())
                {
                    if (list.hash == hash)
                        return list;
                }
                NonExistingHash?.Invoke(hash);
                return null;
            }
        }

        public static HashMap<T> operator +(HashMap<T> map1, HashMap<T> map2)
        {
            var newMap = new HashMap<T>();

            foreach (var list in map1.Iter())
                foreach (var item in list.Iter())
                    newMap.Add(item.value);
            
            foreach (var list in map2.Iter())
                foreach (var item in list.Iter())
                    newMap.Add(item.value);

            return newMap;
        }

        public static explicit operator T[](HashMap<T> map)
        {
            var arr = new T[map.Length];
            var i = 0;
            foreach (var list in map.Iter())
                foreach (var item in list.Iter())
                    arr[i++] = item.value;

            return arr;
        }

        public override string ToString()
        {
            var str = "";
            foreach (var list in Iter())
            {
                str += list.hash + ": ";
                foreach (var item in list.Iter())
                {
                    str += item.value + " | ";
                }
                str += "\n";
            }
            return str;
        }
    }
}
