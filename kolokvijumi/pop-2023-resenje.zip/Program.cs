﻿using System;

namespace HashMapApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //var studMap = new HashMap<Student>();

            //studMap.NonExistingHash += (h) => Console.WriteLine("non exising hash: " + h);

            //studMap.Add(new Student("Srba", 33, 2033));
            //studMap.Add(new Student("Pera", 11, 2011));
            //studMap.Add(new Student("Mika", 12, 2012));
            //studMap.Add(new Student("Laza", 13, 2011));
            //studMap.Add(new Student("Zika", 14, 2011));
            //studMap.Add(new Student("Sima", 15, 2012));

            //studMap.Sort();

            //Console.WriteLine(studMap);
            //Console.WriteLine(studMap["2011"][1]);
            //Console.WriteLine(studMap["2012"][0]);
            //Console.WriteLine(studMap["2033"][0]);

            string s = "B";
            Console.WriteLine(s.CompareTo("A")); //  1 - s ide nakon parametra
            Console.WriteLine(s.CompareTo("B")); //  0 - s je po redosledu isti kao i parametar
            Console.WriteLine(s.CompareTo("C")); // -1 - s ide pre parametra


        }
    }
}
