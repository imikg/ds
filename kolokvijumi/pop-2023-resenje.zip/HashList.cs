﻿using System.Collections.Generic;

namespace HashMapApp
{
    internal class HashList<T> where T : class, IHash
    {
        public string hash;
        public Node<T> firstNode;
        public HashList<T> next;

        public HashList(string hash)
        {
            this.hash = hash;
        }

        public void Add(T val)
        {
            Node<T> newNode = new Node<T>(val);

            if (firstNode == null)
            {
                firstNode = newNode;
                return;
            }

            Node<T> lastNode = null;
            foreach (var item in Iter()) 
                lastNode = item;

            lastNode.next = newNode;
        }

        public IEnumerable<Node<T>> Iter()
        {
            var node = firstNode;
            while (node != null)
            {
                yield return node;
                node = node.next;
            }
        }

        public T this[int index]
        {
            get {
                int i = 0;
                foreach (var item in Iter())
                {
                    if (i == index)
                        return item.value;
                    i++;
                }
                return null;
            }
        }
    }
}
