﻿namespace HashMapApp
{
    internal class Student : IHash
    {
        public string ime;
        public int godina;
        public int broj;

        public Student(string ime, int broj, int godina)
        {
            this.ime = ime;
            this.godina = godina;
            this.broj = broj;
        }

        public string GetHash()
        {
            return godina.ToString();
        }

        public override string ToString()
        {
            return $"{ime} {broj}/{godina}";
        }
    }
}
