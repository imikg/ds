﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HashMapApp
{
    internal class Node<T> where T : class, IHash
    {
        public T value;
        public Node<T> next = null;

        public Node(T val)
        {
            value = val;
        }
    }
}
