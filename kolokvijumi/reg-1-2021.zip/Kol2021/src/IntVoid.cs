﻿using System;

namespace Kol2021
{
    public delegate void IntVoid(int broj);
}
