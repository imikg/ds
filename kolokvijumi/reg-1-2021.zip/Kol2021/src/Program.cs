﻿using System;

namespace Kol2021
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var r1 = new Recnik<string, Student>();
            var r2 = new Recnik<string, Student>();

            IntVoid print = (x) => Console.WriteLine(x);
            r1.PromenaBrojaElemenata += print;
            r2.PromenaBrojaElemenata += print;

            r1.Dodaj("1/2001", new Student("1/2001", "Pera", 7, 8.2f));
            r1.Dodaj("2/2002", new Student("2/2002", "Mika", 8, 8.1f));
            r1.Dodaj("3/2003", new Student("3/2003", "Laza", 9, 7.6f));
            r1.Dodaj("4/2004", new Student("4/2004", "Zika", 4, 9.1f));
            r1.Dodaj("5/2005", new Student("5/2005", "Sima", 5, 6.6f));
            
            r2.Dodaj("11/2001", new Student("1/2001", "Petar", 7, 8.2f));
            r2.Dodaj("2/2002", new Student("2/2002", "Mika", 8, 8.1f));
            r2.Dodaj("33/2003", new Student("3/2003", "Lazar", 9, 7.6f));
            r2.Dodaj("4/2004", new Student("4/2004", "Zika", 4, 9.1f));
            r2.Dodaj("5/2005", new Student("5/2005", "Sima", 5, 6.6f));

            r1["3/2003"] = r2["33/2003"];

            var r3 = r1 + r2;

            foreach (var item in r3.Iter())
            {
                Console.WriteLine(item);
            }
        }
    }
}
