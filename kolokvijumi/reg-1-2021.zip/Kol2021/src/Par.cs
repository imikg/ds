﻿using System;

namespace Kol2021
{
    internal class Par<K, V> 
        where K : class, IEquatable<K>
        where V : class, IEquatable<V>
    {
        public K kljuc;
        public V vrednost;

        public Par(K kljuc, V vrednost)
        {
            this.kljuc = kljuc;
            this.vrednost = vrednost;
        }

        public override string ToString()
        {
            return "(" + kljuc + ", " + vrednost + ")";
        }
    }
}
