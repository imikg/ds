﻿using System;
using System.Collections.Generic;

namespace Kol2021
{
    internal class Recnik<K, V>
        where K : class, IEquatable<K>
        where V : class, IEquatable<V>
    {

        List<Par<K, V>> parovi;

        public event IntVoid PromenaBrojaElemenata;

        public Recnik()
        {
            parovi = new List<Par<K, V>>();
        }

        public void Dodaj(K kljuc, V vrednost)
        {
            Par<K, V> zaIzmeniti = null;
            foreach (var item in parovi)
            {
                if (item.kljuc == kljuc)
                {
                    zaIzmeniti = item;
                    break;
                }
            }

            if (zaIzmeniti != null)
            {
                // Update
                zaIzmeniti.vrednost = vrednost;
            }
            else
            {
                // Add
                parovi.Add(new Par<K, V>(kljuc, vrednost));
                PromenaBrojaElemenata?.Invoke(parovi.Count);
            }
        }

        public V this[K kljuc]
        {
            get
            {
                foreach (var item in parovi)
                {
                    if (item.kljuc == kljuc)
                        return item.vrednost;
                }
                return null;
            }

            set
            {
                foreach (var item in parovi)
                {
                    if (item.kljuc == kljuc)
                        item.vrednost = value;
                }
            }
        }

        public IEnumerable<Par<K, V>> Iter()
        {
            foreach (var item in parovi)
            {
                yield return item;
            }
        }

        public static Recnik<K, V> operator +(Recnik<K, V> r1, Recnik<K, V> r2)
        {
            Recnik<K, V> novi = new Recnik<K, V>();
            
            foreach (var item in r1.parovi)
                novi.Dodaj(item.kljuc, item.vrednost);
            
            foreach (var item in r2.parovi)
                novi.Dodaj(item.kljuc, item.vrednost);

            return novi;
        }

        public static implicit operator List<K>(Recnik<K, V> recnik)
        {
            List<K> list = new List<K>();
            
            foreach (var item in recnik.parovi)
                list.Add(item.kljuc);

            return list;
        }
    }
}
