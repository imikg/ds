﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution {

    /* **************************************************************************************************
     * Klasa Student prilagodjena za smestanje u kolekciju BufferedList<T>
     * ************************************************************************************************** */
    internal class Student : IJednakost<Student> {
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public int Indeks { get; set; }
        public int GodinaUpisa { get; set; }

        public Student(string ime, string prezime, int indeks, int godina) {
            Ime = ime;
            Prezime = prezime;
            Indeks = indeks;
            GodinaUpisa = godina;
        }

        public override string ToString() {
            return Ime + " " + Prezime + " " + Indeks + "/" + GodinaUpisa;
        }

        public bool DaLiSuJednaki(Student item) {
            return (Indeks == item.Indeks && GodinaUpisa == item.GodinaUpisa); // dva studenta su jednaka ukoliko imaju isti indeks i godinu upisa
        }
    }

    /* **************************************************************************************************
     * Klasa Program sa main metodom
     * ************************************************************************************************** */
    class Program {

        public static string LINES = "----------------------------------------------------------------------------------";

        public static void ispisiDaJePrazanBafer() {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("STATICKA METODA: Pokusano uzimanje elementa iz prazong buffer-a");
            Console.ForegroundColor = ConsoleColor.White;
        }

        static void Main(string[] args) {

            BufferedList<Student> bafer1 = new BufferedList<Student>();
            BufferedList<Student> bafer2 = new BufferedList<Student>();

            Student s1 = new Student("Pera", "Peric", 11, 2022);
            Student s2 = new Student("Mika", "Mikic", 12, 2022);
            Student s3 = new Student("Nikola", "Nikolic", 13, 2022);
            Student s4 = new Student("Marko", "Markovic", 14, 2022);
            Student s5 = new Student("Zika", "Peric", 15 ,2022);

            Student s6 = new Student("Pera", "Nikolic", 11, 2023);
            Student s7 = new Student("Mika", "Nikolic", 12, 2023);
            Student s8 = new Student("Nikola", "Nikolic", 13, 2023);
            Student s9 = new Student("Marko", "Nikolic", 14, 2023);
            Student s10 = new Student("Zika", "Nikolic", 15, 2023);

            //////////////////////////////////// PRETPLACIVANJE METODA NA ODGOVARAJUCE EVENT-E U BAFERIMA ////////////////////////////////////

            bafer1.PrazanBafer += ispisiDaJePrazanBafer;                                                                                    // STATICKA METODA
            bafer2.PrazanBafer += () => {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("ANONIMNA METODA: Pokusano uzimanje elementa iz prazong buffer-a");
                Console.ForegroundColor = ConsoleColor.White;
            }; // ANONIMNA METODA

            //////////////////////////////////// DODAVANJE ELEMENATA ////////////////////////////////////

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(LINES);
            Console.WriteLine("Dodavanje elemenata u bafere:");
            Console.WriteLine(LINES);
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Dodavanje u prvi bafer:");
            bafer1.Dodaj(s1);
            bafer1.Dodaj(s2);
            bafer1.Dodaj(s3);
            bafer1.Dodaj(s4);
            bafer1.Dodaj(s5);

            Console.WriteLine("Dodavanje u drugi bafer:");
            bafer2.Dodaj(s6);
            bafer2.Dodaj(s7);
            bafer2.Dodaj(s8);
            bafer2.Dodaj(s9);
            bafer2.Dodaj(s10);

            Console.WriteLine("\n");

            //////////////////////////////////// Pristupanje preko indeksera ////////////////////////////////////

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(LINES);
            Console.WriteLine("Pristupanje elementima preko indeksera:");
            Console.WriteLine(LINES);
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Elementi prvog bafera:");
            Console.WriteLine("\tElement u prvom baferu na indeksu 0 je: [{0}]", bafer1[0]);
            Console.WriteLine("\tElement u prvom baferu na indeksu 1 je: [{0}]", bafer1[1]);
            Console.WriteLine("\tElement u prvom baferu na indeksu 2 je: [{0}]", bafer1[2]);
            Console.WriteLine("\tElement u prvom baferu na indeksu 3 je: [{0}]", bafer1[3]);
            Console.WriteLine("\tElement u prvom baferu na indeksu 4 je: [{0}]", bafer1[4]);
            Console.Write("\tElement u prvom baferu na indeksu 5 je: [{0}]", bafer1[5]);

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(" #Element na indeksu 5 ne postoji, vraca null");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Elementi drugog bafera:");
            Console.WriteLine("\tElement u drugom baferu na indeksu 0 je: [{0}]", bafer2[0]);
            Console.WriteLine("\tElement u drugom baferu na indeksu 1 je: [{0}]", bafer2[1]);
            Console.WriteLine("\tElement u drugom baferu na indeksu 2 je: [{0}]", bafer2[2]);
            Console.WriteLine("\tElement u drugom baferu na indeksu 3 je: [{0}]", bafer2[3]);
            Console.WriteLine("\tElement u drugom baferu na indeksu 4 je: [{0}]", bafer2[4]);
            Console.Write("\tElement u drugom baferu na indeksu 5 je: [{0}]", bafer2[5]);

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(" #Element na indeksu 5 ne postoji, vraca null");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("\n");

            //////////////////////////////////// Ispis elemenata foreach petljom ////////////////////////////////////

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(LINES);
            Console.WriteLine("Prikaz rada foreach petlje za oba bafera:");
            Console.WriteLine(LINES);
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Ispis prvog bafera:");
            foreach (var element in bafer1) Console.WriteLine("\t" + element);

            Console.WriteLine("Ispis drugog bafera:");
            foreach (var element in bafer2) Console.WriteLine("\t" + element);

            Console.WriteLine("\n");

            //////////////////////////////////// Rad operatora + - VERZIJA #1 ////////////////////////////////////

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(LINES);
            Console.WriteLine("Prikaz rada operatora + primenjenog na dva bafera:");
            Console.WriteLine(LINES);
            Console.ForegroundColor = ConsoleColor.White;

            BufferedList<Student> novi_plus_1 = bafer1 + bafer2;
            foreach (var element in novi_plus_1) Console.WriteLine("\t" + element);

            Console.WriteLine("\n");

            //////////////////////////////////// Rad operatora + - VERZIJA #2 ////////////////////////////////////

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(LINES);
            Console.WriteLine("Prikaz rada operatora + primenjenog nad jednim baferom sa prosledjenom vrednoscu:");
            Console.WriteLine(LINES);
            Console.ForegroundColor = ConsoleColor.White;

            BufferedList<Student> novi_plus_2 = bafer1 + new Student("NOVI", "NOVI", 1, 2020);
            foreach (var element in novi_plus_2) Console.WriteLine("\t" + element);

            //////////////////////////////////// Rad operatora - ////////////////////////////////////

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(LINES);
            Console.WriteLine("Prikaz rada operatora -:");
            Console.WriteLine(LINES);
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Pre poziva operatora -:");
            foreach (var element in bafer1) Console.WriteLine("\t" + element);

            BufferedList<Student> novi_minus_operator = bafer1 - 3;
            Console.WriteLine("Nakon poziva operatora - (izbacena 3 elementa):");
            foreach (var element in novi_minus_operator) Console.WriteLine("\t" + element);

            Console.WriteLine("\n");

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(LINES);
            Console.WriteLine("Izbacivanje svih elemenata preko operatora -:");
            Console.WriteLine(LINES);
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Pre poziva operatora -:");
            foreach (var element in novi_minus_operator) Console.WriteLine("\t" + element);

            novi_minus_operator = bafer1 - 3;
            Console.WriteLine("Nakon poziva operatora - (izbaceni su svi elementi):");
            foreach (var element in novi_minus_operator) Console.WriteLine("\t" + element);

            Console.WriteLine("\n");

            //////////////////////////////////// Provera operatora ==  i != ////////////////////////////////////

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(LINES);
            Console.WriteLine("Prikaz rada operatora (==) i (!=):");
            Console.WriteLine(LINES);
            Console.ForegroundColor = ConsoleColor.White;

            BufferedList<Student> test1 = new BufferedList<Student>();
            BufferedList<Student> test2 = new BufferedList<Student>();
            BufferedList<Student> test3 = new BufferedList<Student>();
            BufferedList<Student> test4 = new BufferedList<Student>();

            test1.Dodaj(s1);
            test2.Dodaj(s1);
            test3.Dodaj(s3);
            test4.Dodaj(s3);
            test4.Dodaj(s2);
            
            Console.WriteLine("Sadrzaj listi:");
            Console.WriteLine("\tBafer test1:"); foreach (var item in test1) Console.WriteLine("\t\t" + item);

            Console.WriteLine("\tBafer test2:"); foreach (var item in test2) Console.WriteLine("\t\t" + item);

            Console.WriteLine("\tBafer test3:"); foreach (var item in test3) Console.WriteLine("\t\t" + item);

            Console.WriteLine("\tBafer test4:"); foreach (var item in test4) Console.WriteLine("\t\t" + item);

            Console.WriteLine("==");
            Console.WriteLine("test1 == test2: {0}", (test1 == test2));
            Console.WriteLine("test2 == test1: {0}", (test2 == test1));
            Console.WriteLine("test1 == test3: {0}", (test1 == test3));
            Console.WriteLine("test2 == test3: {0}", (test2 == test3));
            Console.WriteLine("test2 == test4: {0}", (test2 == test3));

            Console.WriteLine("!=");
            Console.WriteLine("test1 != test2: {0}", (test1 != test2));
            Console.WriteLine("test2 != test1: {0}", (test2 != test1));
            Console.WriteLine("test1 != test3: {0}", (test1 != test3));
            Console.WriteLine("test2 != test3: {0}", (test2 != test3));
            Console.WriteLine("test2 != test4: {0}", (test2 != test3));

            Console.WriteLine("\n");

            //////////////////////////////////// Eksplicitna konverzija u niz ////////////////////////////////////

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(LINES);
            Console.WriteLine("Eksplicitna konverzija bafera 2 u niz studenata:");
            Console.WriteLine(LINES);
            Console.ForegroundColor = ConsoleColor.White;

            Student[] nizStudenata = (Student[])bafer2;
            foreach (var student in nizStudenata) Console.WriteLine(student);

            Console.WriteLine("\n");

            //////////////////////////////////// Praznjenje svih bafera ////////////////////////////////////

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(LINES);
            Console.WriteLine("Praznjenje bafera:");
            Console.WriteLine(LINES);
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Duzina bafera: {0}", bafer1.Length);
            var x = bafer1 - 1000;                                      // pokusava da skine prvih 1000 elemenata
            Console.WriteLine(LINES);

            Console.WriteLine("Duzina bafera: {0}", bafer2.Length);
            var y = bafer2 - 1000;                                      // pokusava da skine prvih 1000 elemenata
            Console.WriteLine(LINES);

            novi_minus_operator.PrazanBafer += ispisiDaJePrazanBafer;
            novi_plus_1.PrazanBafer += ispisiDaJePrazanBafer;
            novi_plus_2.PrazanBafer += ispisiDaJePrazanBafer;

            Console.WriteLine("Duzina bafera: {0}", novi_minus_operator.Length);
            var z = novi_minus_operator - 1000;                         // pokusava da skine prvih 1000 elemenata
            Console.WriteLine(LINES);

            Console.WriteLine("Duzina bafera: {0}", novi_plus_1.Length);
            var t = novi_plus_1 - 1000;                                 // pokusava da skine prvih 1000 elemenata
            Console.WriteLine(LINES);

            Console.WriteLine("Duzina bafera: {0}", novi_plus_2.Length);
            var s = novi_plus_2 - 1000;                                 // pokusava da skine prvih 1000 elemenata
            Console.WriteLine(LINES);

            Console.WriteLine("\n");

            //////////////////////////////////// Kreiranje novog buffera operatorom - nad praznim bufferom ////////////////////////////////////

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(LINES);
            Console.WriteLine("Kreiranje novog buffera operatorom - nad praznim bufferom: (ocekivano ce biti prazan)");
            Console.WriteLine(LINES);
            Console.ForegroundColor = ConsoleColor.White;

            var novi = bafer2 - 10;
            foreach (var element in novi)
                Console.WriteLine(element);

            Console.WriteLine("\n");
            Console.WriteLine(LINES);
            Console.WriteLine(LINES);
            Console.WriteLine("\n");

            Console.Write("Press any key to continue...");
            Console.ReadKey();
        }
    }
}
