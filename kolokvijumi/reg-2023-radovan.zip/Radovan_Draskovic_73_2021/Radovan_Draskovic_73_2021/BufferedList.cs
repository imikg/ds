﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solution {

    public delegate void Delegat();

    class BufferedList<T> : IEnumerable<T> 
        where T : class, IJednakost<T> {

        public Node<T> pocetak;             // prvi element u buffer-u
        public event Delegat PrazanBafer;   // event - okida se ukoliko se skida element sa bafera koji je prazan

        public int Length => _getLength();  // property za dobijanje duzine liste


        /* ******************************************************************
         * Konstruktor, jednostavan
         * ****************************************************************** */
         public BufferedList() {
            pocetak = null;
        }

        /* ******************************************************************
         * Metoda za dodavanje novog elementa na kraj bafera
         * ****************************************************************** */
        public void Dodaj(T element) {

            Console.WriteLine("\t\tDodavanje novog elementa: [{0}]", element);

            Node<T> noviElement = new Node<T>(element);

            if(pocetak == null) {
                pocetak = noviElement;
                return;
            }

            Node<T> current = pocetak;
            while (current.sledeci != null) current = current.sledeci;
            current.sledeci = noviElement;
        }

        /* ******************************************************************
         * Metod za izbacivanje elementa sa pocetka buffer-a
         *      Vraca prvi element ukoliko postoji
         *      Ukoliko je buffer prazan vraca null
         * ****************************************************************** */
        public T Izbaci() {
            if(Length == 0) {
                PrazanBafer?.Invoke();
                return null;
            }
            
            Node<T> pocetniNode = pocetak;
            pocetak = pocetak.sledeci;

            Console.WriteLine("\t\tElement [{0}] uspesno izbacen iz buffer-a", pocetniNode.vrednost);
            return pocetniNode.vrednost;
        }

        /* ******************************************************************
         * Operator + : Verzija #1
         *      elementi_levog_buffera , elementi_desnog_buffera
         * ****************************************************************** */
         public static BufferedList<T> operator + (BufferedList<T> first, BufferedList<T> second) {
            BufferedList<T> novaLista = new BufferedList<T>();

            foreach (var element in first) novaLista.Dodaj(element);
            foreach (var element in second) novaLista.Dodaj(element);

            return novaLista;
        }

        /* ******************************************************************
         * Operator + : Verzija #2
         * ****************************************************************** */
         public static BufferedList<T> operator + (BufferedList<T> lista, T vrednost) {
            BufferedList<T> novaLista = new BufferedList<T>();

            foreach (var element in lista) novaLista.Dodaj(element);
            novaLista.Dodaj(vrednost);

            return novaLista;
        }

        /* ******************************************************************
         * Operator -
         *      Kreira se novi buffer ali se prvo skida [int vrednost]
         *      elemenata sa pocetka prosledjenog buffer-a. Nako toga,
         *      novi buffer sadrzi ostale elemente
         * ****************************************************************** */
         public static BufferedList<T> operator -(BufferedList<T> lista, int vrednost) {
            BufferedList<T> novi = new BufferedList<T>();
            int counter = 0;
            T skinutaVrednost;
            while(counter < vrednost) {
                skinutaVrednost = lista.Izbaci();
                if (skinutaVrednost == null) {
                    // lista.PrazanBafer?.Invoke(); // pokusano je skidanje elementa sa praznog bafera
                    break;
                }
                counter++;
            }

            foreach (var element in lista) novi.Dodaj(element);

            return novi;
        }

        /* ******************************************************************
         * Operator ==
         * ****************************************************************** */
         public static bool operator == (BufferedList<T> first, BufferedList<T> second) {

            if (first.Length != second.Length) return false;        // ukoliko nisu iste duzine -> nisu jednaki

            int indeks = 0;
            while(indeks < first.Length) {
                if (!first[indeks].DaLiSuJednaki(second[indeks])) return false;
                indeks++;
            }
            return true;
        }

        /* ******************************************************************
         * Operator !=
         * ****************************************************************** */
        public static bool operator !=(BufferedList<T> first, BufferedList<T> second) {
            return !(first == second);
        }

        /* ******************************************************************
         * Indekser
         *      Omogucava samo get()
         * ****************************************************************** */
        public T this[int indeks] {
            get {
                if (indeks >= Length) return null;

                int counter = 0;
                Node<T> current = pocetak;
                while(current != null && counter < indeks) { current = current.sledeci; counter++; }

                return current.vrednost;
            }
        }

        /* ******************************************************************
         * Iterator kroz buffer - podrzano implementacijom IEnumerable<T>
         *                        i yield return
         * ****************************************************************** */
        public IEnumerator<T> GetEnumerator() {
            Node<T> current = pocetak;

            while(current != null) {
                yield return current.vrednost;
                current = current.sledeci;
            }
        }

        IEnumerator IEnumerable.GetEnumerator() {
            return GetEnumerator();
        }

        /* ******************************************************************
         * Eksplicitna konverzija u niz elemenata tipa T
         * ****************************************************************** */
        public static explicit operator T[](BufferedList<T> lista) {
            T[] niz = new T[lista.Length];
            int indeks = 0;

            foreach (var item in lista) niz[indeks++] = item;

            return niz;
        }

        /* ******************************************************************
         * PRIVATE HELPER METOD - vraca broj elemenata
         * ****************************************************************** */
        private int _getLength() {
            int counter = 0;

            Node<T> current = pocetak;
            while(current != null) {
                counter++;
                current = current.sledeci;
            }

            return counter;
        }
    }
}
